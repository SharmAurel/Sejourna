package com.example.sejournaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SejournaApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
