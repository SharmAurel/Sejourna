package com.Miage.Sejourna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SejournaApplicationTests {

	@Test
	void contextLoads() {
	}

}
