package com.example.sejournaapi.Activities;

public class Chill extends Activities{

    public Chill(int id, double prix, String description, String titre, double latitude, double longitude) {
        super(id, prix, description, titre, latitude, longitude, "Chill");
    }
}
