package com.example.sejournaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SejournaApiApplication {

    public static void main(String[] args) {

    }

}
