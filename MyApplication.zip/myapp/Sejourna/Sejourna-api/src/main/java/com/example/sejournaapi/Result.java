package com.example.sejournaapi;

public class Result {
}
