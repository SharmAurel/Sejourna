package com.example.sejournaapi.Activities;

public class Other extends Activities{
    public Other(int id, double prix, String description, String titre, double latitude, double longitude) {
        super(id, prix, description, titre, latitude, longitude, "Other");
    }
}
