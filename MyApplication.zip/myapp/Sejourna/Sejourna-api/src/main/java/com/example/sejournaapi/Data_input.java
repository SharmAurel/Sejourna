package com.example.sejournaapi;

public class Data_input {
}
