package com.example.sejournaapi;

public abstract class User {

}