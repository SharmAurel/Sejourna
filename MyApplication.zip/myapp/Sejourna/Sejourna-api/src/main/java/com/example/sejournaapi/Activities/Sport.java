package com.example.sejournaapi.Activities;

public class Sport extends Activities{
    public Sport(int id, double prix, String description, String titre, double latitude, double longitude) {
        super(id, prix, description, titre, latitude, longitude, "Sport");
    }
}
