package com.example.sejournaapi.Activities;

public class Touristic extends Activities{
    public Touristic(int id, double prix, String description, String titre, double latitude, double longitude) {
        super(id, prix, description, titre, latitude, longitude, "Touristic");
    }
}
