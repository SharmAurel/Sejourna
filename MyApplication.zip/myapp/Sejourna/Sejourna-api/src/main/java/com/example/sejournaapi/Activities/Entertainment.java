package com.example.sejournaapi.Activities;

public class Entertainment extends Activities{
    public Entertainment(int id, double prix, String description, String titre, double latitude, double longitude) {
        super(id, prix, description, titre, latitude, longitude, "Entertainment");
    }
}
