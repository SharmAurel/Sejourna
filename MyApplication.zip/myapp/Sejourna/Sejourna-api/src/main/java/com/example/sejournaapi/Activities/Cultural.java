package com.example.sejournaapi.Activities;

public class Cultural extends Activities{
    public Cultural(int id, double prix, String description, String titre, double latitude, double longitude) {
        super(id, prix, description, titre, latitude, longitude, "Cultural");
    }
}
