package com.example.myapplication;

public class Data_input {
}
