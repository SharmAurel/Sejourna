package com.example.myapplication;

public class Visitor extends User {
    public Visitor(String ip, String loca) {
        super(ip, loca);
    }
}
