package com.example.myapplication.Activities;

public class Touristic extends Activities {
    public Touristic(String country, String city, String street_name, Double cost, int required_age, int number_of_people_required) {
        super(country, city, street_name, cost, required_age, number_of_people_required);
    }
}
