package com.example.myapplication;

public class Menu {
}
